package recurrent_CSCI201L_Project;

public class StringConstants {

	// servlets
	public static final String LOGIN_SERVLET = "/LoginServlet";
	public static final String SIGN_UP_SERVLET = "/SignUpServlet";
	public static final String SEARCH_SERVLET = "/SearchServlet";

	// jsp and html used strings
	public static final String BIG_FEED_JSP = "HomePage.jsp";

}
